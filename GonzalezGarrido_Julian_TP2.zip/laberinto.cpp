//JULIAN GONZALEZ GARRIDO

#include "laberinto.h"


Laberinto::Laberinto()

{ 
laberinto = std::vector<std::vector<Celda>>(ALTO, std::vector<Celda>(ANCHO, PARED));
}

//////////////////////////////////////////////////////////////

void Laberinto::generarLaberinto(int x, int y) {
    laberinto[y][x] = CAMINO;
    imprimirLaberinto();
    
    int dirs[4] = {0, 1, 2, 3};
    for (int i = 0; i < 4; ++i) {
        int r = i + rand() % (4 - i);
        swap(dirs[i], dirs[r]);

        int dx = 0, dy = 0;
        if (dirs[i] == 0) dx = 2;
        else if (dirs[i] == 1) dx = -2;
        else if (dirs[i] == 2) dy = 2;
        else dy = -2;

        int nx = x + dx;
        int ny = y + dy;

        if (esValido(nx, ny) && !tieneCaminoAdyacente(nx, ny)) {
            laberinto[y + dy / 2][x + dx / 2] = CAMINO;
            generarLaberinto(nx, ny);
        }
    }
}

////////////////////////////////////////////////////////////////

void Laberinto::imprimirLaberinto() {
    for (int i = 0; i < ALTO; ++i) {
        for (int j = 0; j < ANCHO; ++j) {
            if (laberinto[i][j] == PARED) {
                attron(COLOR_PAIR(1));  // Color para las paredes
                mvaddch(i, j, ' ' );
                attroff(COLOR_PAIR(1));
            } else {
                mvaddch(i, j, ' ' | COLOR_PAIR(2));  // Color para el camino
            }
        }
    }
    refresh();
    this_thread::sleep_for(chrono::milliseconds(vAnimacion));
    
}

///////////////////////////////////////////////////////////////

//inicia la grilla
void Laberinto::inicializarLaberinto() {
    for (int i = 1; i < ALTO - 1; i += 2) {
        for (int j = 1; j < ANCHO - 1; j += 2) {
            laberinto[i][j] = CAMINO;
        }
    }
}

/////////////////////////////////////////////////////////////

//¿Entra dentro de la cuadricula?
bool Laberinto::esValido(int x, int y) {
    return x >= 0 && x < ANCHO && y >= 0 && y < ALTO;
}

//////////////////////////////////////////////////////////////

//¿Es camino?
bool Laberinto::esCamino(int x, int y) {
    return esValido(x, y) && laberinto[y][x] == CAMINO;
}

////////////////////////////////////////////////////////////////

//¿Tiene camino adyacente?
bool Laberinto::tieneCaminoAdyacente(int x, int y) {
    return (esCamino(x + 1, y) || esCamino(x - 1, y) || esCamino(x, y + 1) || esCamino(x, y - 1));
}
