// JULIAN GONZALEZ GARRIDO

#pragma once
#include <iostream>
#include <ncurses.h>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <thread>

using namespace std;

class Laberinto
{

public:
Laberinto();

int ALTO = 40; // Alto de la ventana x defecto
int ANCHO = 120; // Ancho de la ventana x defecto
int vAnimacion = 50; //velocidad de la animacion x defecto

void inicializarLaberinto();
void generarLaberinto(int x, int y);
void imprimirLaberinto();
enum Celda { PARED,CAMINO,};
bool esCamino(int x, int y);

private:

std::vector<std::vector<Celda>> laberinto;
bool animacion;
bool esValido(int x, int y);
bool tieneCaminoAdyacente(int x, int y);

};