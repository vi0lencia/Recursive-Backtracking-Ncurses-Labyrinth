//JULIAN GONZALEZ GARRIDO

#include <iostream>
#include <ncurses.h>
#include <ctime>
#include "laberinto.h"


using namespace std;

Laberinto miLaberinto;


//=========================================================================
// CONSTANTES
//=========================================================================


const int ANCHO = 40;
const int ALTO = 20;
const int DELAY = 30;
const int ANIMACION = 1;

enum direcciones
{
	DETENIDO,
	IZQUIERDA,
	DERECHA,
	ARRIBA,
	ABAJO
};

const char FONDO = ' ';
const char CABEZA = 'X';

const int PAR_FONDO = 1;
const int PAR_TIPITO = 2;
const int PAR_LLAVE = 3;
const int PAR_GAMEOVER = 4;
const int PAR_PARED = 5;
const int PAR_SALIDA = 6;


//=========================================================================
//VARIABLES GLOBALES
//=========================================================================

bool game_over;
int x, y, llaves;
int x_llave, y_llave, x_salida, y_salida;
int nTipito;

int tipitoX[1000];
int tipitoY[1000];

direcciones direccion;

bool puertaAbierta = false;

bool salir;


//=========================================================================
//Funciones globales
//=========================================================================

void setup();
void input();
void update();
void draw();
void gameover();

//=========================================================================
//MAIN
//=========================================================================

int main()
{

	initscr();
	noecho();
	curs_set(FALSE);
	keypad(stdscr, TRUE);
	nodelay(stdscr, TRUE);

	if (LINES < ALTO || COLS < ANCHO)
	{
		endwin();
		printf("La terminal tiene que tener como mínimo %dx%d\n\n", ANCHO, ALTO);
		exit(1);
	}

	if (has_colors() == FALSE)
	{
		endwin();
		printf("Tu terminal no soporta color\n\n");
		exit(1);
	}
	start_color();

	setup();

	// Para que entre al loop la primera vez
	salir = false;

	
	miLaberinto.generarLaberinto(1, 1);
	
	while (!salir)
	{
	miLaberinto.imprimirLaberinto();
		while (!game_over)
		{   
            input();
			update();
			draw();
		}

		gameover();
	}

	endwin();


	cout << endl;
    
	return 0;
}

//=========================================================================
//SETUP
//=========================================================================

void setup(){

	game_over = FALSE;
	direccion = DETENIDO;
	llaves = 0;

	// Configuraciones del laberinto
	miLaberinto.ALTO = ALTO - 1;
    miLaberinto.ANCHO = ANCHO - 2;
	miLaberinto.vAnimacion = ANIMACION;

	//INICIALIZAMOS EL LABERINTO
	miLaberinto.inicializarLaberinto();
    
	//init_pair(PAR_FONDO, COLOR_WHITE, COLOR_BLACK);
	init_pair(PAR_TIPITO, COLOR_RED, COLOR_BLUE);
	init_pair(PAR_LLAVE, COLOR_MAGENTA, COLOR_BLUE);
    init_pair(PAR_PARED, COLOR_GREEN,COLOR_GREEN);
	init_pair(PAR_GAMEOVER, COLOR_BLACK, COLOR_RED);
	init_pair(PAR_SALIDA, COLOR_YELLOW,COLOR_YELLOW);

    	srand(time(NULL));

	// Generar coordenadas aleatorias para llave
	do {
    x_llave = (rand() % (ANCHO - 3)) + 2;
    y_llave = (rand() % (ALTO - 3)) + 2;
} while (!miLaberinto.esCamino(x_llave, y_llave));

	//Generar coordenadas aleatorias para SALIDA
	do{
	x_salida = (rand() % (ANCHO - 3)) + 2;
	y_salida = (rand() % (ALTO - 3)) + 2;
	} while (!miLaberinto.esCamino(x_salida, y_salida));

    // Generar coordenadas aleatorias para tipito
	do{
    x = rand() % (ANCHO - 2) + 1; // Evitar bordes
    y = rand() % (ALTO - 2) + 1;  // Evitar bordes
	}while (!miLaberinto.esCamino(x,y));

	
}
//=========================================================================
//INPUT

void input()
{
    int tecla = getch();

    switch (tecla)
    {
    case KEY_UP:
        direccion = ARRIBA;
        break;
    case KEY_DOWN:
        direccion = ABAJO;
        break;
    case KEY_LEFT:
        direccion = IZQUIERDA;
        break;
    case KEY_RIGHT:
        direccion = DERECHA;
        break;
    case 27:
        game_over = TRUE;
        break;
    default:
        direccion = DETENIDO;
        break;
    }

}

//=========================================================================
//UPDATE

void update()
{

	tipitoX[0] = x + 1;
	tipitoY[0] = y + 1;

	int prevX = x;
    int prevY = y;

	switch (direccion)
	{
	case ARRIBA:
    if (y <= 1 ) // Si toca el borde superior, frena
        direccion = DETENIDO;
        else
		y--;
        
		break;
	case ABAJO:
    if (y >= ALTO - 2)
     direccion = DETENIDO;
        else
		y++;
		break;
	case IZQUIERDA:
    if (x <= 1)
    direccion = DETENIDO;
        else
		x--;
		break;
	case DERECHA:
		if (x >= ANCHO - 2)
        direccion = DETENIDO;
        else
        x++;
		break;
	default:
		break;
	}

	 // Verificar si la nueva posición es un camino o una pared
    if (!miLaberinto.esCamino(x, y))
    {
        // Si es una pared, mantener la posición anterior
        x = prevX;
        y = prevY;
    }

	//NO PASAR LOS BORDES
    if (x >= ANCHO - 1 || x <= 0 || y >= ALTO - 1 || y <= 0)
			direccion = DETENIDO;

	if (x == x_llave && y == y_llave)
	{
		puertaAbierta = true;
		x_llave = 0;
		y_llave = 0;
		llaves++;
	}

	if (x == x_salida && y == y_salida && puertaAbierta == true)
	{
		game_over = true;
	}
	


}

//=========================================================================
//DRAW

void draw()
{
    miLaberinto.imprimirLaberinto();

	box(stdscr, 0, 0);
	mvprintw(0, 5, "[ Llaves: %d    ]", llaves);
	for (int y = 1; y < ALTO - 1; y++)
	mvhline(y, 1, ' ', ANCHO - 2);

	attron(COLOR_PAIR(PAR_TIPITO));
	mvaddch(y, x, CABEZA | A_BOLD);
	attroff(COLOR_PAIR(PAR_TIPITO));

	attron(COLOR_PAIR(PAR_LLAVE));
	mvaddch(y_llave, x_llave, ACS_DIAMOND);
	attroff(COLOR_PAIR(PAR_LLAVE));

	attron(COLOR_PAIR(PAR_SALIDA));
	mvaddch(y_salida, x_salida, ACS_BLOCK);
	attroff(COLOR_PAIR(PAR_SALIDA));

	refresh();
	//delay_output(DELAY); POSIBLE DELAY PARA OUTPUT (CAUSA REFRESH MAS TRABADO)
}


//=========================================================================
//GAMEOVER

void gameover()
{
	attron(COLOR_PAIR(PAR_GAMEOVER) | A_BOLD);

	// Dibujamos el fondo rojo del cartel gameover.
	for (int y = 10; y < 16; y++)
		mvhline(y, 40, ' ', 40);

	// Usamos ASCII extendido con las constantes de ncurses (ACS).
	// ver el archivo ncurses-extended-characters.png
	// Dibujamos el marco externo del cartel gameover.
	// Las cuatro esquinas.
	mvaddch(9, 39, ACS_ULCORNER);
	mvaddch(9, 80, ACS_URCORNER);
	mvaddch(16, 39, ACS_LLCORNER);
	mvaddch(16, 80, ACS_LRCORNER);

	// Los marcos horizontales.
	mvhline(9, 40, ACS_HLINE, 40);
	mvhline(16, 40, ACS_HLINE, 40);

	// Los marcos verticales.
	mvvline(10, 39, ACS_VLINE, 6);
	mvvline(10, 80, ACS_VLINE, 6);

	mvprintw(12, 55, "GAME OVER");
	mvprintw(13, 50, "VOLVER A JUGAR? (S/N)");
	attroff(COLOR_PAIR(PAR_GAMEOVER) | A_BOLD);

	int opcion = getch();

	if (opcion == 's' || opcion == 'S')
	{
		game_over = false;
		setup(); // Para iniciar todo nuevamente.
	}
	else if (opcion == 'n' || opcion == 'N')
	{
		salir = TRUE;
	}
}
